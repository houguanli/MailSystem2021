package com.hou.mail.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpSession;

//@RestController
@Controller
public class HController {
//    @RequestMapping("/test/succ")
//    public String succe(){
//        return "success";
//    }
//    @RequestMapping("/test/suc")
//    public String test(
//            @RequestParam("email") String email,
//            HttpSession httpSession
//    ){
//        System.out.println(email);
//        return "redirect:succ";
//    }
//    @ResponseBody
//    @RequestMapping("/settings/birthday")
//    public String birthday(){
//        return "Hello sp boot!";
//    }
}
